# TASK 1
# Landing Page
The landing page is for a car dealership, highlighting their expertise in car dealing. The page features sections like Home, About, Services, Featured, and Contact. The main focus is on the Sedan, showcasing its sleek design, advanced technology, powerful yet efficient engine, safety features, and luxurious interior. The page aims to attract customers by emphasizing the blend of performance and comfort the Sedan offers for both city driving and long road trips.
# Live Link
https://papaya-hummingbird-8b3023.netlify.app
![Screenshot (56)](https://github.com/habi-navitha/OCTANET_NOVEMBER/assets/141555190/860b64e1-8ea4-4053-b463-5b154e92db4e)

# TASK 2
# TO-DO LIST
The webpage is a simple and functional To-Do List application. It allows users to add new tasks with details such as the task title, due date, priority, and description. The tasks can be managed and organized effectively, providing a clear and user-friendly interface for keeping track of various tasks and deadlines.
# Live Link
https://polite-biscuit-132e14.netlify.app

![Screenshot (57)](https://github.com/habi-navitha/OCTANET_NOVEMBER/assets/141555190/62c19e1d-8068-4b55-b03f-140dda1c7398)
